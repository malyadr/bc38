import React from "react";
import ProgressStepper from ".";

export default {
  title: "Molecules/Stepper",
  component: ProgressStepper,
};

export const ProgressBar = () => <ProgressStepper step={0} />;
